// Simple Job Fair Registration Form JavaScript

// Validation Rules
const ValidationRules = {
    candidateName: /^[A-Za-z][A-Za-z\s]{2,}$/,
    email: /^[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}$/,
    username: /^[a-z0-9]{4,16}$/,
    password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!]).{8,}$/,
    phone: /^(\+91[-\s]?)?[6-9]\d{9}$/,
    pincode: /^\d{6}$/,
    graduationYear: /^(202[0-9]|2030)$/,
    resumeUrl: /^https:\/\/[^\s]+$/
};

// Simple Candidate Class
class Candidate {
    constructor(data) {
        this.candidateName = data.candidateName;
        this.email = data.email;
        this.username = data.username;
        this.password = data.password;
        this.phone = data.phone;
        this.pincode = data.pincode;
        this.graduationYear = data.graduationYear;
        this.resumeUrl = data.resumeUrl;
        this.registrationDate = new Date().toISOString();
    }
}

// Mock Services
const Services = {
    async checkUsername(username) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const unavailable = ['admin', 'test', 'user', 'demo'];
                const available = !unavailable.includes(username.toLowerCase());
                resolve({ available });
            }, 1000);
        });
    },

    async verifyEmail(email) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const domain = email.split('@')[1]?.toLowerCase();
                const disposable = ['tempmail.org', '10minutemail.com'].includes(domain);
                resolve({ valid: !disposable });
            }, 800);
        });
    },

    async submitForm(data) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    success: true,
                    confirmationNumber: 'JF' + Date.now().toString().slice(-6)
                });
            }, 1500);
        });
    }
};

// DOM Elements
const form = document.getElementById('registrationForm');
const submitBtn = document.getElementById('submitBtn');
const resetBtn = document.getElementById('resetBtn');
const successMessage = document.getElementById('successMessage');

// Utility Functions
function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(fieldId + 'Error');
    
    field.classList.add('invalid');
    field.classList.remove('valid');
    errorElement.textContent = message;
    errorElement.classList.add('show');
}

function showSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(fieldId + 'Error');
    
    field.classList.remove('invalid');
    field.classList.add('valid');
    errorElement.classList.remove('show');
}

function showStatus(fieldId, message, type) {
    const statusElement = document.getElementById(fieldId + 'Status');
    if (statusElement) {
        statusElement.textContent = message;
        statusElement.className = `status-message ${type}`;
    }
}

// Validation Functions
function validateField(fieldId, value) {
    const rule = ValidationRules[fieldId];
    if (!rule) return true;
    
    if (!value || !value.trim()) {
        showError(fieldId, 'This field is required');
        return false;
    }
    
    if (!rule.test(value)) {
        const messages = {
            candidateName: 'Name must start with a letter and be at least 3 characters',
            email: 'Please enter a valid email address',
            username: 'Username must be 4-16 characters, lowercase letters and digits only',
            password: 'Password must be at least 8 characters with uppercase, lowercase, digit, and special character',
            phone: 'Please enter a valid Indian phone number',
            pincode: 'Pincode must be exactly 6 digits',
            graduationYear: 'Graduation year must be between 2020 and 2030',
            resumeUrl: 'Resume URL must start with https://'
        };
        showError(fieldId, messages[fieldId]);
        return false;
    }
    
    showSuccess(fieldId);
    return true;
}

function updatePasswordStrength(password) {
    const strengthElement = document.getElementById('passwordStrength');
    
    if (!password) {
        strengthElement.textContent = '';
        return;
    }
    
    let strength = 0;
    if (/[a-z]/.test(password)) strength++;
    if (/[A-Z]/.test(password)) strength++;
    if (/\d/.test(password)) strength++;
    if (/[@#$%^&+=!]/.test(password)) strength++;
    if (password.length >= 8) strength++;
    
    if (strength < 3) {
        strengthElement.textContent = 'Weak Password';
        strengthElement.className = 'strength-indicator weak';
    } else if (strength < 5) {
        strengthElement.textContent = 'Medium Password';
        strengthElement.className = 'strength-indicator medium';
    } else {
        strengthElement.textContent = 'Strong Password';
        strengthElement.className = 'strength-indicator strong';
    }
}

// Async Validation
async function checkUsernameAvailability(username) {
    if (!validateField('username', username)) return;
    
    showStatus('username', 'Checking availability...', 'checking');
    
    try {
        const result = await Services.checkUsername(username);
        if (result.available) {
            showStatus('username', 'Username is available', 'valid');
        } else {
            showError('username', 'Username not available');
            showStatus('username', 'Username not available', 'invalid');
        }
    } catch (error) {
        showStatus('username', 'Could not check availability', 'invalid');
    }
}

async function verifyEmailDomain(email) {
    if (!validateField('email', email)) return;
    
    showStatus('email', 'Verifying email...', 'checking');
    
    try {
        const result = await Services.verifyEmail(email);
        if (result.valid) {
            showStatus('email', 'Email is valid', 'valid');
        } else {
            showError('email', 'Please use a valid email address');
            showStatus('email', 'Invalid email domain', 'invalid');
        }
    } catch (error) {
        showStatus('email', 'Could not verify email', 'invalid');
    }
}

// Event Listeners
function setupEventListeners() {
    // Basic validation on blur
    Object.keys(ValidationRules).forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('blur', (e) => {
                validateField(fieldId, e.target.value);
            });
        }
    });
    
    // Password strength
    document.getElementById('password').addEventListener('input', (e) => {
        updatePasswordStrength(e.target.value);
    });
    
    // Async validations
    document.getElementById('username').addEventListener('blur', (e) => {
        if (e.target.value) {
            checkUsernameAvailability(e.target.value);
        }
    });
    
    document.getElementById('email').addEventListener('blur', (e) => {
        if (e.target.value) {
            verifyEmailDomain(e.target.value);
        }
    });
    
    // Form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
        
        // Validate all fields
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        const candidate = new Candidate(data);
        
        let isValid = true;
        Object.keys(ValidationRules).forEach(fieldId => {
            if (!validateField(fieldId, data[fieldId])) {
                isValid = false;
            }
        });
        
        if (isValid) {
            try {
                const result = await Services.submitForm(candidate);
                document.getElementById('confirmationNumber').textContent = result.confirmationNumber;
                successMessage.classList.add('show');
                form.reset();
            } catch (error) {
                alert('Registration failed. Please try again.');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Register for Job Fair';
            }
        } else {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Register for Job Fair';
        }
    });
    
    // Reset form
    resetBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to reset the form?')) {
            form.reset();
            document.querySelectorAll('.error-message').forEach(el => el.classList.remove('show'));
            document.querySelectorAll('input').forEach(el => {
                el.classList.remove('valid', 'invalid');
            });
            document.querySelectorAll('.status-message').forEach(el => el.textContent = '');
            document.getElementById('passwordStrength').textContent = '';
        }
    });
    
    // Close success message
    successMessage.addEventListener('click', () => {
        successMessage.classList.remove('show');
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
});