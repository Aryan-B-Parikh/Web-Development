// Simple TechFest Registration Form JavaScript

// Validation Rules
const ValidationRules = {
    fullName: /^[A-Za-z][A-Za-z\s.'-]{2,49}$/,
    phoneNumber: /^(\+91[-\s]?)?[6-9]\d{9}$/,
    emailAddress: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    collegeId: /^[A-Za-z]{2,4}\d{4}\d{3,4}$/,
    collegeName: /^[A-Za-z][A-Za-z\s.,&'-]{4,99}$/,
    motivation: /^.{20,300}$/
};

// Track Descriptions
const TrackDescriptions = {
    'web-development': 'Build modern, responsive web applications using the latest technologies.',
    'mobile-app': 'Create innovative mobile applications for iOS and Android platforms.',
    'ai-ml': 'Develop intelligent systems using machine learning algorithms.',
    'data-science': 'Analyze complex datasets and derive meaningful insights.',
    'cybersecurity': 'Focus on protecting digital systems and networks from threats.',
    'game-development': 'Create engaging games using modern development frameworks.'
};

// Student Registration Class
class StudentRegistration {
    constructor(data) {
        this.fullName = data.fullName;
        this.emailAddress = data.emailAddress;
        this.phoneNumber = data.phoneNumber;
        this.collegeId = data.collegeId;
        this.collegeName = data.collegeName;
        this.course = data.course;
        this.yearOfStudy = data.yearOfStudy;
        this.participationTrack = data.participationTrack;
        this.teamSize = data.teamSize;
        this.teamMembers = data.teamMembers || [];
        this.motivation = data.motivation;
        this.agreeTerms = data.agreeTerms;
        this.registrationId = this.generateRegistrationId();
        this.registrationDate = new Date().toISOString();
    }
    
    generateRegistrationId() {
        const prefix = 'TF2024';
        const timestamp = Date.now().toString().slice(-6);
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `${prefix}${timestamp}${random}`;
    }
}

// Mock Services
const Services = {
    async checkEmailUniqueness(email) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const existingEmails = ['john.doe@example.com', 'test@college.edu'];
                const isUnique = !existingEmails.includes(email.toLowerCase());
                resolve({ unique: isUnique });
            }, 1000);
        });
    },
    
    async verifyCollegeId(collegeId) {
        return new Promise((resolve) => {
            setTimeout(() => {
                const match = collegeId.match(/^([A-Za-z]{2,4})(\d{4})(\d{3,4})$/);
                if (match) {
                    const [, dept, year] = match;
                    const validDepartments = ['CSE', 'IT', 'ECE', 'MECH', 'BCA', 'MCA'];
                    const currentYear = new Date().getFullYear();
                    const studentYear = parseInt(year);
                    
                    const isDeptValid = validDepartments.includes(dept.toUpperCase());
                    const isYearValid = studentYear >= currentYear - 6 && studentYear <= currentYear;
                    
                    resolve({
                        valid: isDeptValid && isYearValid,
                        department: dept.toUpperCase(),
                        year: studentYear
                    });
                } else {
                    resolve({ valid: false });
                }
            }, 800);
        });
    },
    
    async submitRegistration(data) {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    success: true,
                    registrationId: data.registrationId
                });
            }, 1500);
        });
    }
};

// DOM Elements
const form = document.getElementById('techfestForm');
const submitBtn = document.getElementById('submitRegistration');
const resetBtn = document.getElementById('resetForm');
const successMessage = document.getElementById('successMessage');

// Utility Functions
function showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(fieldId + 'Error');
    
    field.classList.add('invalid');
    field.classList.remove('valid');
    errorElement.textContent = message;
    errorElement.classList.add('show');
}

function showSuccess(fieldId) {
    const field = document.getElementById(fieldId);
    const errorElement = document.getElementById(fieldId + 'Error');
    
    field.classList.remove('invalid');
    field.classList.add('valid');
    errorElement.classList.remove('show');
}

function showStatus(fieldId, message, type) {
    const statusElement = document.getElementById(fieldId + 'Status');
    if (statusElement) {
        statusElement.textContent = message;
        statusElement.className = `status-message ${type}`;
    }
}

// Validation Functions
function validateField(fieldId, value) {
    const rule = ValidationRules[fieldId];
    if (!rule) return true;
    
    if (!value || !value.trim()) {
        showError(fieldId, 'This field is required');
        return false;
    }
    
    if (!rule.test(value)) {
        const messages = {
            fullName: 'Name must start with a letter and be 3-50 characters',
            phoneNumber: 'Please enter a valid Indian phone number',
            emailAddress: 'Please enter a valid email address',
            collegeId: 'College ID format: CSE2021001 (Department+Year+Number)',
            collegeName: 'College name must be 5-100 characters',
            motivation: 'Motivation must be between 20-300 characters'
        };
        showError(fieldId, messages[fieldId]);
        return false;
    }
    
    showSuccess(fieldId);
    return true;
}

function validateSelect(fieldId) {
    const value = document.getElementById(fieldId).value;
    if (!value) {
        showError(fieldId, 'Please select an option');
        return false;
    }
    showSuccess(fieldId);
    return true;
}

// Async Validation
async function checkEmailUniqueness(email) {
    if (!validateField('emailAddress', email)) return;
    
    showStatus('emailAddress', 'Checking email...', 'checking');
    
    try {
        const result = await Services.checkEmailUniqueness(email);
        if (result.unique) {
            showStatus('emailAddress', '✓ Email is available', 'valid');
        } else {
            showError('emailAddress', 'Email already registered');
            showStatus('emailAddress', '✗ Email already registered', 'invalid');
        }
    } catch (error) {
        showStatus('emailAddress', 'Could not verify email', 'invalid');
    }
}

async function verifyCollegeId(collegeId) {
    if (!validateField('collegeId', collegeId)) return;
    
    showStatus('collegeId', 'Verifying college ID...', 'checking');
    
    try {
        const result = await Services.verifyCollegeId(collegeId);
        if (result.valid) {
            showStatus('collegeId', `✓ Valid ${result.department} ${result.year}`, 'valid');
        } else {
            showError('collegeId', 'Invalid college ID');
            showStatus('collegeId', '✗ Invalid college ID', 'invalid');
        }
    } catch (error) {
        showStatus('collegeId', 'Could not verify ID', 'invalid');
    }
}

// Track Selection
function handleTrackSelection(track) {
    const descriptionElement = document.getElementById('trackDescription');
    
    if (track && TrackDescriptions[track]) {
        descriptionElement.textContent = TrackDescriptions[track];
        descriptionElement.classList.add('show');
    } else {
        descriptionElement.classList.remove('show');
    }
}

// Team Size Handler
function handleTeamSizeChange(teamSize) {
    const teamMembersSection = document.getElementById('teamMembersSection');
    const teamMembersList = document.getElementById('teamMembersList');
    
    const size = parseInt(teamSize);
    
    if (size > 1) {
        teamMembersSection.style.display = 'block';
        teamMembersList.innerHTML = '';
        
        for (let i = 2; i <= size; i++) {
            const memberDiv = document.createElement('div');
            memberDiv.className = 'team-member-input';
            memberDiv.innerHTML = `
                <span class="member-label">Member ${i}:</span>
                <input type="text" name="teamMember${i}" id="teamMember${i}" 
                       placeholder="Enter team member name" required>
            `;
            teamMembersList.appendChild(memberDiv);
        }
    } else {
        teamMembersSection.style.display = 'none';
        teamMembersList.innerHTML = '';
    }
}

// Character Count
function updateCharCount(fieldId, maxLength) {
    const field = document.getElementById(fieldId);
    const countElement = document.getElementById(fieldId + 'Count');
    
    if (field && countElement) {
        const currentLength = field.value.length;
        countElement.textContent = currentLength;
        
        if (currentLength > maxLength * 0.9) {
            countElement.style.color = '#dc3545';
        } else if (currentLength > maxLength * 0.7) {
            countElement.style.color = '#ffc107';
        } else {
            countElement.style.color = '#6c757d';
        }
    }
}

// Check Form Validity
function checkFormValidity() {
    const requiredFields = ['fullName', 'emailAddress', 'phoneNumber', 'collegeId', 'collegeName', 'course', 'yearOfStudy', 'participationTrack', 'teamSize', 'motivation'];
    const termsAgreed = document.getElementById('agreeTerms').checked;
    
    let isValid = true;
    
    // Check required fields
    requiredFields.forEach(fieldId => {
        const element = document.getElementById(fieldId);
        if (!element.classList.contains('valid')) {
            isValid = false;
        }
    });
    
    // Check team members if applicable
    const teamSize = parseInt(document.getElementById('teamSize').value);
    if (teamSize > 1) {
        for (let i = 2; i <= teamSize; i++) {
            const memberInput = document.getElementById(`teamMember${i}`);
            if (!memberInput || !memberInput.value.trim()) {
                isValid = false;
                break;
            }
        }
    }
    
    submitBtn.disabled = !(isValid && termsAgreed);
}

// Download JSON
function downloadJSON(data) {
    const dataStr = JSON.stringify(data, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    
    const link = document.createElement('a');
    link.href = URL.createObjectURL(dataBlob);
    link.download = `techfest-registration-${data.registrationId}.json`;
    link.click();
}

// Event Listeners
function setupEventListeners() {
    // Basic validation
    Object.keys(ValidationRules).forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('blur', (e) => {
                validateField(fieldId, e.target.value);
                checkFormValidity();
            });
        }
    });
    
    // Select validation
    ['course', 'yearOfStudy', 'participationTrack', 'teamSize'].forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
            field.addEventListener('change', (e) => {
                validateSelect(fieldId);
                checkFormValidity();
            });
        }
    });
    
    // Async validations
    document.getElementById('emailAddress').addEventListener('blur', (e) => {
        if (e.target.value) {
            checkEmailUniqueness(e.target.value);
        }
    });
    
    document.getElementById('collegeId').addEventListener('blur', (e) => {
        if (e.target.value) {
            verifyCollegeId(e.target.value);
        }
    });
    
    // Track selection
    document.getElementById('participationTrack').addEventListener('change', (e) => {
        handleTrackSelection(e.target.value);
    });
    
    // Team size
    document.getElementById('teamSize').addEventListener('change', (e) => {
        handleTeamSizeChange(e.target.value);
        checkFormValidity();
    });
    
    // Character count
    document.getElementById('motivation').addEventListener('input', (e) => {
        updateCharCount('motivation', 300);
    });
    
    // Terms agreement
    document.getElementById('agreeTerms').addEventListener('change', () => {
        checkFormValidity();
    });
    
    // Form submission
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
        
        const formData = new FormData(form);
        const data = Object.fromEntries(formData);
        
        // Get team members
        const teamSize = parseInt(data.teamSize || 0);
        const teamMembers = [];
        for (let i = 2; i <= teamSize; i++) {
            const memberName = document.getElementById(`teamMember${i}`)?.value;
            if (memberName && memberName.trim()) {
                teamMembers.push(memberName.trim());
            }
        }
        data.teamMembers = teamMembers;
        
        const registration = new StudentRegistration(data);
        
        try {
            const result = await Services.submitRegistration(registration);
            document.getElementById('registrationId').textContent = registration.registrationId;
            successMessage.classList.add('show');
            
            // Setup download button
            document.getElementById('downloadJSON').onclick = () => {
                downloadJSON(registration);
            };
            
        } catch (error) {
            alert('Registration failed. Please try again.');
            submitBtn.disabled = false;
            submitBtn.textContent = 'Register for TechFest';
        }
    });
    
    // Reset form
    resetBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to reset the form?')) {
            form.reset();
            document.querySelectorAll('.error-message').forEach(el => el.classList.remove('show'));
            document.querySelectorAll('input, select, textarea').forEach(el => {
                el.classList.remove('valid', 'invalid');
            });
            document.querySelectorAll('.status-message').forEach(el => el.textContent = '');
            document.getElementById('trackDescription').classList.remove('show');
            document.getElementById('teamMembersSection').style.display = 'none';
            updateCharCount('motivation', 300);
            checkFormValidity();
        }
    });
    
    // Close success message
    successMessage.addEventListener('click', () => {
        successMessage.classList.remove('show');
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    updateCharCount('motivation', 300);
    checkFormValidity();
});